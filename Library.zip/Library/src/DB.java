import java.sql.*;

public class DB 
{
	Connection con;
	Statement stmt;
	ResultSet rs;
	
	public DB() throws Exception
	{
		Class.forName("com.mysql.jdbc.Driver");
		String url = "jdbc:mysql://localhost/library";
		con = DriverManager.getConnection(url,"root","");
		stmt = con.createStatement();
	}
	
	public void update(String qry) throws Exception
	{
		stmt.executeUpdate(qry);
	}
	
	public ResultSet execute(String qry) throws Exception
	{
		rs=stmt.executeQuery(qry);
		return rs;
	}
        
        public int getbookcatid() throws Exception
        {
            String qry = "select ifnull(max(bookcatid),0)max from tbbookcat";
            rs = stmt.executeQuery(qry);
            rs.next();
            int n = rs.getInt("max");
            n++;
            return n;
        }
}